<?php

/*
 * Process the tick boxes and insert the target, person setting the target and deadline
 */

require_once("../../config.php");

global $USER, $CFG, $COURSE;

$count = 0;
$type = $_POST['type'];
$courseid = $_POST['courseid'];
$userid = $_POST['userid'];
$checkboxes = $_POST['checkbox'];
$target = $_POST['target'];
$title = $_POST['title'];
$date = $_POST['date'];
$url = $_POST['url'];
$url2 = $_POST['url2'];
$courserelated = $_POST['course_related'];
$rag = $_POST['rag'];
$radio = $_POST['medal'];

echo $radio;
//set  the rag colour by status

if ($rag == 'Green') {
    $ragstatus = 0;
} elseif ($rag == 'Amber') {
    $ragstatus = 1;
} elseif ($rag == 'Red') {
    $ragstatus = 2;
}

if ($courserelated == 'ON') {
    $courserelated = '1';
    $relatedcourse = $courseid;
} else {
    $courserelated = '0';
    $relatedcourse = '0';
}


//echo 'date is ' . $date . '<br/>';
$date = strtotime($date);

$currentdate = date('d-m-Y h:i:s');
//echo $currentdate;
$currentdate = strtotime($currentdate);


if ($type == '--Select--') {
    echo '<h3><font color= red>No type set please set some - redirecting you back to the setting page</font></h3>';
    echo '<meta http-equiv="refresh" content="2;url=' . $url . '">';
    exit;
}

//check for blank sections
if (($target == '') && ($type != 'Medals')) {
    echo '<h3><font color= red>No details set please set some - redirecting you back to the setting page</font></h3>';
    echo '<meta http-equiv="refresh" content="2;url=' . $url . '">';
    exit;
}

//set targets
if ($type == 'Target') {

    if ($title == '') {
        echo '<h3><font color= red>No target title set please set one - redirecting you back to the target setting page</font></h3>';
        echo '<meta http-equiv="refresh" content="2;url=' . $url . '">';
        exit;
    }

    if ($date == '') {
        echo '<h3><font color= red>No date set please set one - redirecting you back to the target setting page</font></h3>';
        echo '<meta http-equiv="refresh" content="2;url=' . $url . '">';
        exit;
    }

    $status = '0';
} elseif ($type == 'Review') {
    $status = '0';
} elseif ($type == 'Concern') {
    $status = '1';
} elseif ($type == 'Reason for Status Change') {
    $status = '2';
} elseif ($type == 'Contribution') {
    $status = '3';
}

echo '<h3><font color=red>Processing details and redirecting you to your course page</font></h3>';

//set the things
foreach ($checkboxes as $box) {
    // echo $box . 'is checked <br/>';
    //insert queries to add the targets go here based on their id - probably need to get
    echo 'user id is: ' . $userid;
    if ($type == 'Target') {
        $table = 'mdl_ilptarget_posts';
        $insert = "INSERT INTO " . $table . " (setforuserid, setbyuserid, course, courserelated, targetcourse, timecreated, timemodified, deadline, name, targetset, status, format) ";
        $values = "VALUES ('" . $box . "','" . $userid . "','" . $courseid . "','" . $courserelated . "','" . $relatedcourse . "','" . $currentdate . "','" . $currentdate . "','" . $date . "','" . $title . "','" . $target . "','" . $status . "','1')";
    } elseif ($type == 'RAG - Traffic Light') {
        $status = '2';
        //check if a record already exists
        $queryrag = "SELECT * FROM mdl_ilpconcern_status WHERE userid='" . $box . "'";
        $resultrag = mysql_query($queryrag);
        $num_rows = mysql_num_rows($resultrag);

        //if a record exists update it else insert a new record
        if ($num_rows >= 1) {
            $insert = "UPDATE mdl_ilpconcern_status ";
            $values = "SET modified='" . $currentdate . "', modifiedbyuser='" . $userid . "', status='" . $ragstatus . "' WHERE userid='" . $box . "'";
        } else {
            $insert = "INSERT INTO mdl_ilpconcern_status (userid, created, modified, modifiedbyuser, status ";
            $values = "VALUES ('" . $box . "','" . $currentdate . "','" . $currentdate . "','" . $userid . "','" . $ragstatus . "'";
        }
        //Insert a reason for status change
        $table2 = 'mdl_ilpconcern_posts';
        $insert2 = "INSERT INTO " . $table2 . " (setforuserid, setbyuserid, course, courserelated, targetcourse, timecreated, timemodified, deadline, concernset, status, format) ";
        $values2 = "VALUES ('" . $box . "','" . $userid . "','" . $courseid . "','" . $courserelated . "','" . $relatedcourse . "','" . $currentdate . "','" . $currentdate . "','" . $currentdate . "','" . $target . "','" . $status . "','1')";
    } elseif ($type == 'Medals') {
        // get students logon name
        $query = "SELECT * FROM mdl_user WHERE id='" . trim($box) . "'";
        echo '</br/>' . $query . '</br/>';
        $result = mysql_query($query);

        while ($row = mysql_fetch_assoc($result)) {
            $logon = $row['username'];
            echo 'username is: ' . $logon;
        }
        //
        //
        mysql_select_db('medals') or die('Unable to select the database');
        //cehck if they already have the medal
        $query = "select * from students s join badges_link b on s.id=b.student_id where students_name='" . $logon . "'";
        echo $query;
        $result = mysql_query($query);
        $num_rows = mysql_num_rows($result);
        echo 'rows is ' . $num_rows;


        if ($num_rows == '0') {

            $query = "SELECT * from students WHERE students_name='" . $logon . "'";
            $result = mysql_query($query);
            while ($row = mysql_fetch_assoc($result)) {
                $id = $row['id'];
                echo 'id is ' . $id . '<br/> ';
            }

            if ($id != '') {
                $query = "INSERT INTO badges_link SET student_id='" . $id . "', badge_id='" . $radio . "'";
                echo $query;
                mysql_query($query);
                $id = '';
            }
        }
        mysql_select_db('moodle') or die('Unable to select the database');
    } else {
        $table = 'mdl_ilpconcern_posts';
        $insert = "INSERT INTO " . $table . " (setforuserid, setbyuserid, course, courserelated, targetcourse, timecreated, timemodified, deadline, concernset, status, format) ";
        $values = "VALUES ('" . $box . "','" . $userid . "','" . $courseid . "','" . $courserelated . "','" . $relatedcourse . "','" . $currentdate . "','" . $currentdate . "','" . $currentdate . "','" . $target . "','" . $status . "','1')";
    }

    $queryinsert = $insert . $values;
    $queryinsert2 = $insert2 . $values2;

    echo '<h3>Processing target for ' . $box . '</h3><br/>';
    echo $queryinsert . '<br/>';
    echo $queryinsert2 . '<br/>';


    mysql_query($queryinsert);
    mysql_query($queryinsert2);

    $count = $count + 1;
}

echo '<br/>Target set for ' . $count . ' students';

echo '<meta http-equiv="refresh" content="2;url=' . $url2 . '">';
?>