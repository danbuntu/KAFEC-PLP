<?php
require_once("../../config.php");

global $USER, $CFG, $COURSE;


$userid = $USER->id;
//echo '<br> Userid is ' . $userid;
?>

<script type="text/javascript" src="./jquery/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="./jquery/js/jquery-ui-1.8.6.custom.min.js"></script>
<script type="text/javascript" src="./jquery/js/jquery.infieldlabel.min.js"></script>
<link rel="stylesheet" href="./jquery/css/ui-lightness/jquery-ui-1.8.6.custom.css" />
<link rel="stylesheet" href="./group_targets.css" />

<div id="page">
    <div id="layout">

        <?php
//get the page id
        $courseid = $_GET['courseid'];
        $contextid = $_GET['var1'];
        //  echo 'courseid ' . $courseid;
        //  echo ' contextid ' . $contextid;
//get the course name and dispaly it
        $querycoursename = "SELECT fullname FROM {$CFG->prefix}course WHERE id='" . $courseid . "'";

//echo $querycoursename;

        $resultcourse = mysql_query($querycoursename);
        $group_name = 'All groups';
        //catch and check the filter
        if (isset($_POST['groups'])) {
            $group_name = htmlentities($_POST['groups']);
            //get the group id
            if ($group_name != 'ALl groups') {
                $query_group_id = "SELECT * FROM {$CFG->prefix}groups WHERE name='" . $group_name . "' AND courseid='" . $courseid . "'";
               //  echo $query_group_id;
                $result_group_id = mysql_query($query_group_id);
                while ($row = mysql_fetch_assoc($result_group_id)) {
                    $group_id = $row['id'];
                }
            } else {
                $group_id = '';
            }
        }
        //    echo $group_name . ' ' . $group_id;
        ?>

        <table width="100%"><tr><td>

                    <?php
                    while ($row = mysql_fetch_assoc($resultcourse)) {
                        echo '<h1>Update Multiple PLPS:  <br/>';
                        echo 'Current course is: <a href="' . $CFG->wwwroot . '/course/view.php?id=' . $courseid . '">' . $row['fullname'] . '</a></h1>';
                    }
                    ?>

                </td>
                <td rowspan="2"  style="text-align: right;">
                    <img src="User-Group-icon.png" width="156" height="156" alt="User-Group-icon"/>
                </td>
            <tr><td>
                    <h2>Before setting a group target please check that it wouldn't be better set as a moodle assignment</h2>
                    <h2>Name colour denotes current RAG traffic light status</h2>
                </td></tr></table>

        <?php
                    // get the url
                    $domain = $_SERVER['HTTP_HOST'];
                    $scriptname = $_SERVER['SCRIPT_NAME'];
                    $path = $_SERVER['QUERY_STRING'];
                    // echo $domain;
                    // echo $scriptname;
                    // echo $path;
                    $url = 'http://' . $domain . $scriptname . '?' . $path;
                    $url2 = 'http://' . $domain . '/course/view.php?id=' . $courseid;

//echo 'Course id is: ' . $courseid;
//get the course name
                    $query = "SELECT fullname FROM {$CFG->prefix}course WHERE id='" . $courseid . "'";

                    echo '<br/>';
//echo $query;
                    echo '<br/>';
                    $result = mysql_query($query);

//select and show all students on this course used roleid 5 to indentify students
                    // $querystudents = "SELECT a.userid, firstname, lastname FROM {$CFG->prefix}role_assignments a JOIN {$CFG->prefix}user u on a.userid=u.id where contextid='" . $contextid . "' AND a.roleid='5' order by lastname";
                    $select = "SELECT  distinct u.id, u.firstname, u.lastname";
                    $from = " FROM {$CFG->prefix}role_assignments a JOIN {$CFG->prefix}user u on a.userid=u.id LEFT JOIN {$CFG->prefix}groups_members gm ON gm.userid=a.userid";
                    $where = " WHERE contextid='" . $contextid . "'";
                    if ($group_name == 'All groups') {
                        $andgroup = " ";
                    } elseif ($group_name != 'All groups') {
                        $andgroup = " AND gm.groupid='" . $group_id . "'";
                    }
                    $and = "AND a.roleid='5' order by lastname";


                    $querystudents = $select . $from . $where . $andgroup . $and;

                    // echo $querystudents;
                    echo '<br/>';
//echo $querystudents;
                    echo '<br/>';
                    $resultsstudents = mysql_query($querystudents);

                    $count = 0;
        ?>

                    <div id="students">
                        <h3>Students on this course</h3>

            <?php
                    //filter by groups
                    $query = "SELECT * FROM {$CFG->prefix}groups WHERE courseid='" . $courseid . "'";
                    $result = mysql_query($query);
                    $num_rows = mysql_num_rows($result);

                    if ($num_rows == 0) {
                        echo 'No groups found on this course';
                    } else {
                        echo '<label>Filter by group </label>';
                        echo '<form name="filter" action="view.php?courseid=' . $courseid . '&var1=' . $contextid . '" method="POST">';
                        echo '<select name="groups" id="groups">';
                        echo '<option>All groups</option>';
                        while ($row = mysql_fetch_assoc($result)) {
                            echo '<option>' . $row['name'] . '</option>';
                        }
                        echo '</select>';
                        echo '<input type="submit" value="filter" name="filter" />';
                        echo '</form>';
                        echo 'Currently filtered by ' . $group_name;
                    }
            ?>

                    <form name="process" action="process_targets.php" method="POST">

                        <table><tr><td colspan="4" style="text-align: center;">
                                    <b>Select / Deselect all</b><input type="checkbox" onclick="toggleChecked(this.checked)"></tr>

                    <?php
                    while ($row = mysql_fetch_assoc($resultsstudents)) {
                        $id = $row['id'];
                        //echo 'IDs are ' . $id;
                        $firstname = $row['firstname'];
                        $lastname = $row['lastname'];
                        //$status = $row['status'];
                        //
                        //get the rag
                        $queryrag = "SELECT status FROM mdl_ilpconcern_status WHERE userid='" . $id . "'";
                        $resultrag = mysql_query($queryrag);
                        $num_rows_rag = mysql_num_rows($resultrag);

                        if ($num_rows_rag > 0) {
                            while ($row2 = mysql_fetch_assoc($resultrag)) {
                                $status = $row2['status'];
                            }
                        } else
                            $status = '0';

                        if (($status == '0') or ($status == null)) {
                            $colour = 'green';
                        } elseif ($status == '1') {

                            $colour = 'amber';
                        } elseif ($status == '2') {
                            $colour = 'red';
                        }

                        //check if count is odd or even to create two columns
                        if ($count % 2) {
                            //odd
                            echo '<td><font color="' . $colour . '"> ' . $firstname . ' ' . $lastname . '</font></td><td> <input type="hidden" name="firstname[]" value="' . $firstname . '"  ><input type="hidden" name="lastname[]" value="' . $lastname . '"  ></td><td><input type="checkbox" class="checkbox" name="checkbox[]" value="' . $id . '"   /> </td></tr>';
                        } else {
                            //even
                            echo '<tr><td><font color="' . $colour . '"> ' . $firstname . ' ' . $lastname . '</font></td><td> <input type="hidden" name="firstname[]" value="' . $firstname . '"  ><input type="hidden" name="lastname[]" value="' . $lastname . '"  ></td><td><input type="checkbox" class="checkbox" name="checkbox[]" value="' . $id . '"   /> </td>';
                        }

                        $count = $count + 1;
                    }
                    ?>
                </table>
                <?php echo 'Total number of students' . $count; ?>
            </div>

            <div id="targets">
                <h3>Select Type and Enter Details</h3>

                <select name="type" id="select_type">
                    <option>--Select--</option>
                    <option>Target</option>
                    <option>Concern</option>
                    <option>Reason for Status Change</option>
                    <option>Contribution</option>
                    <option>RAG - Traffic Light</option>
                    <option>Medals</option>
                </select>
            <p/>
                <label id="rag_title" for="rag"><br/><b>Select RAG</b></label>
                <select name="rag" id="rag">
                    <option>--Select--</option>
                    <option>Green</option>
                    <option>Amber</option>
                    <option>Red</option>
                </select>

                <label id="target_name_title" for="target_name"><b>Target Name</b></label>
                <input id="target_name" type="text" name="title" size="52" />


                    <label id="datepicker_title" for="datepicker"><br/><b>Target Deadline</b></label>
                    <input type="text" id="datepicker" name="date">

                <label id="details_title" for="details"><b>Enter Details</b></label>
                <textarea name="target" rows="8" cols="40" id="details"></textarea>


                <br/><label id="checkbox_title">The target is related to this course</label><input type="checkbox" id="checkbox" name="course_related" value="ON" checked />

              


                <div id="medals_div">

                <?php

                   mysql_select_db('medals') or die('Unable to select the database');
                    $querymedals = "SELECT * FROM badges";
                    $resultsbadges = mysql_query($querymedals);
                    $num_rows = mysql_num_rows($resultsbadges);
                    //echo 'num rows: ' . $num_rows;
                    echo '<h3>Select medals</h3>';
                    echo '**Warning the student must have manual mtg set on the flightplan for medals to work**';
                    echo '<table>';
                    while ($row = mysql_fetch_assoc($resultsbadges)) {

                        echo '<tr><td>' . $row['name'] . ' ';
                        echo '</td><td><img src="http://' . $domain . '/badges/images/' . $row['icon'] . '.png"/></td>';

                        echo '<td>';
                        //<input type="checkbox" id="checkbox_medal" name="checkbox_medal[]" value="' . $row['id'] . '" />';
                        echo '<input type="radio" name="medal" value="' . $row['id'] . '"   />';
                            echo '</td></tr>';
                    }
                    echo '</table>';
                ?>
                </div>
                <!-- pass the course id and userid -->
                <input type="hidden" name="courseid" value=" <?php echo $courseid ?> "/>
                <input type="hidden" name="userid" value=" <?php echo $userid ?> "/>
                <input type="hidden" name="url" value=" <?php echo $url ?> "/>
                <input type="hidden" name="url2" value=" <?php echo $url2 ?> "/>

            <br/>
            <input type="submit" value="Assign this to selected users" name="submit" />
            </form>

        </div>

    </div>
    <!-- end the layout div -->
</div>


<script type="text/javascript">
    function toggleChecked(status) {
        $(".checkbox").each( function() {
            $(this).attr("checked",status);
        })
    }
</script>


<script>
    $(function() {
        $( "#datepicker" ).datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true
        });
    });
</script>


<script type="text/javascript">
    $(function(){
        //initially hide the textbox
        $("#target_name").hide();
        $("#target_name_title").hide();
        $("#datepicker").hide();
        $("#datepicker_title").hide();
        $("#rag").hide();
        $("#rag_title").hide();
        $("#details").hide();
        $("#details_title").hide();
        $("#checkbox").hide();
        $("#checkbox_title").hide();
        $("#medals_div").hide();
        $("#medals_title").hide();
        $("#medal").hide();
        $('#select_type').change(function() {
            if($(this).find('option:selected').val() == "Target"){
                $("#target_name").show();
                $("#datepicker").show();
                $("#datepicker_title").show();
                $("#target_name_title").show();
                $("#rag").hide();
                $("#rag_title").hide();
                $("#details").show();
                $("#details_title").show();
                $("#checkbox").show();
                $("#checkbox_title").show();
            } else if ($(this).find('option:selected').val() == "RAG - Traffic Light"){
                $("#rag").show();
                $("#rag_title").show();
                $("#target_name").hide();
                $("#datepicker").hide();
                $("#target_name_title").hide();
                $("#datepicker_title").hide();
                $("#details").show();
                $("#details_title").show();
                $("#checkbox").hide();
                $("#checkbox_title").hide();
                $("#medals_div").hide();


            } else if ($(this).find('option:selected').val() == "Medals"){

                $("#medals_div").show();
                $("#target_name").hide();
                $("#datepicker").hide();
                $("#target_name_title").hide();
                $("#datepicker_title").hide();
                $("#details").hide();
                $("#details_title").hide();
                $("#checkbox").hide();
                $("#checkbox_title").hide();
                $("#rag").hide();
                $("#rag_title").hide()

            }else{
                $("#target_name").hide();
                $("#datepicker").hide();
                $("#target_name_title").hide();
                $("#datepicker_title").hide();
                $("#rag").hide();
                $("#rag_title").hide();
                $("#details").show();
                $("#details_title").show();
                $("#checkbox").show();
                $("#checkbox_title").show();
                $("#medals_div").hide();
            }
        });

    });
</script>
