<?php

$string['plp_group_targets'] = 'Update Multiple PLPs';



?>



